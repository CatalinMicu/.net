﻿namespace BackendSkeleton.Controllers.Account
{
    public class RegisterResponseDTO : BaseResponse
    {
        public string Token { get; set; }
    }
}
