﻿namespace BackendSkeleton.Controllers.Account
{
    public class LoginResponseDTO : BaseResponse
    {
        public string Token { get; set; }
    }
}