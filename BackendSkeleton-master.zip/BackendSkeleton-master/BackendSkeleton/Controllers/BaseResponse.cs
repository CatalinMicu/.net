﻿namespace BackendSkeleton.Controllers
{
    public class BaseResponse
    {
        public string Error { get; set; }
    }
}
