﻿namespace BackendSkeleton
{
    public static class Enums
    {
        public enum SortType
        {
            FirstNameAscending,
            LastNameAscending,
            FirstNameDescending,
            LastNameDescending,
        }
    }
}
